# Aim : Write a program add.py that takes 2 numbers as command line arguments and prints its sum.
import sys
num1 = int(sys.argv[1])
num2 = int(sys.argv[2])
print("Sum of num1 and num2 is " , (num1 + num2))