# AIM : Write a program to demonstratebasic data type in python.
a = 5
print("value of a is " , a ," it is type of " , type(a))
b = 5.5
print("value of a is " , b ," it is type of " , type(b))
c = "messi"
print("value of c is " , c ," it is type of " , type(c))
d = True
print("value of d is " , d ," it is type of " , type(d))
e = (1,2,3)
print("value of e is " , e ," it is type of " , type(e))
f = [4,5,6]
print("value of f is " , f ," it is type of " , type(f))
g = {"name":"messi", "age":37}
print("value of g is " , g ," it is type of " , type(g))
h = {1,1,4,2}
print("value of h is " , h ," it is type of " , type(h))

