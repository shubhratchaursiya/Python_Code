# Aim : Write a program using a for loop that loops over a sequence.
s = (1,2,3,4,5)
for it in s:
     print(it)