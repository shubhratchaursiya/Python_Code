# Aim : Write a program using a while loop that asks the user for a number, and prints a countdown from that number to zero.
num = int(input("Enter the number for the countdown "))
while(num>=0):
     print(num)
     num -=1