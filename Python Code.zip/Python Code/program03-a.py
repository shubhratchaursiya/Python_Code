#  Write a Program for checking whether the givennumber is an even number or not.
num = int(input("Enter a number "))
if(num % 2 == 0):
     print("Given number is an even number ")
else:
     print("Given number is a odd number ")