# Aim : Using a for loop, write a program that prints out the decimal equivalents of 1/2, 1/3, 1/4, . . . , 1/10
for i in range (2,11) :
     num = 1/i
     print(f"1/{i} = {num:.2f}")