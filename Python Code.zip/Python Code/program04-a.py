# Write a Program to demonstrate list and tuple in python.
list = [1,2,2,3]
list.append(4)
list.remove(2)
print("Values in list are : " ,list)
tuple = (1,2,3)
print("First element of the tuple is ",tuple[0])
print("Values in tuple are : " , tuple)